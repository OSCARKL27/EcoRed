import React, { useState } from "react";

export default function EcoRedApp() {
  const [historial, setHistorial] = useState([
    { fecha: "15/05/2025", material: "Papel y cartón", cantidad: "3 kg", comentario: "Material recolectado en casa" },
    { fecha: "18/05/2025", material: "Botellas PET", cantidad: "12 unidades", comentario: "Reciclaje semanal" }
  ]);

  return (
    <div className="min-h-screen bg-green-50 text-gray-800">
      <header className="bg-green-700 text-white p-6 text-center shadow">
        <h1 className="text-3xl font-bold">EcoRed</h1>
        <p className="text-sm">Promoviendo el reciclaje responsable en comunidades urbanas</p>
      </header>

      <nav className="bg-green-600 text-white flex justify-center gap-6 p-3 font-semibold">
        <a href="#inicio" className="hover:underline">Inicio</a>
        <a href="#tips" className="hover:underline">Tips de Reciclaje</a>
        <a href="#historial" className="hover:underline">Mi Historial</a>
        <a href="#logros" className="hover:underline">Logros</a>
      </nav>

      <main className="p-6 max-w-4xl mx-auto">
        <section id="inicio" className="mb-10">
          <h2 className="text-2xl font-bold text-green-800 mb-2">Bienvenido a EcoRed</h2>
          <p>Esta plataforma te ayudará a llevar un seguimiento de tus actividades de reciclaje, aprender buenas prácticas y mantenerte motivado con logros ecológicos. ¡Juntos construimos comunidades más limpias!</p>
        </section>

        <section id="tips" className="mb-10">
          <h2 className="text-2xl font-bold text-green-800 mb-2">Tips de Reciclaje</h2>
          <ul className="list-disc pl-6">
            <li>Separa tus residuos en orgánicos, inorgánicos y reciclables.</li>
            <li>Limpia los envases antes de reciclarlos.</li>
            <li>Reutiliza materiales antes de desecharlos.</li>
            <li>Evita el uso de plásticos de un solo uso.</li>
          </ul>
        </section>

        <section id="historial" className="mb-10">
          <h2 className="text-2xl font-bold text-green-800 mb-4">Mi Historial</h2>
          <table className="w-full border border-gray-300 bg-white">
            <thead>
              <tr className="bg-green-100">
                <th className="border px-4 py-2">Fecha</th>
                <th className="border px-4 py-2">Material</th>
                <th className="border px-4 py-2">Cantidad</th>
                <th className="border px-4 py-2">Comentario</th>
              </tr>
            </thead>
            <tbody>
              {historial.map((item, index) => (
                <tr key={index} className="hover:bg-green-50">
                  <td className="border px-4 py-2">{item.fecha}</td>
                  <td className="border px-4 py-2">{item.material}</td>
                  <td className="border px-4 py-2">{item.cantidad}</td>
                  <td className="border px-4 py-2">{item.comentario}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section id="logros">
          <h2 className="text-2xl font-bold text-green-800 mb-2">Logros</h2>
          <ul className="list-disc pl-6">
            <li>⭐ Primer Reciclaje Completado</li>
            <li>⭐ 10 Materiales Clasificados</li>
            <li>⭐ Hábito Semanal Formado</li>
          </ul>
        </section>
      </main>

      <footer className="bg-green-700 text-white text-center p-4 mt-10">
        &copy; 2025 EcoRed - Facultad de Informática, UAS
      </footer>
    </div>
  );
}